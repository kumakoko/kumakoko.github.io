#include<stdio.h>


void main(int argc,char *argv[])
{
  FILE *fp1,*fp2;
  long xsize,ysize,buf;
  char name[24];
  unsigned short ground;
  unsigned short i,s1,s2,s3,s4;
  int x,y;

  if(argc<2)
    {
      printf("����Ӣ�۾������ĵ�ͼת��ΪTile2D�ĵ�ͼ\n");
      printf("�÷�:����ĵ�ͼ�� ����ĵ�ͼ��\n");
      exit(1);
    }
  fp1=fopen(argv[1],"rb");
  if(fp1==0)
   {
     printf("����:�ļ� \"%s\" �򿪴���!\n",argv[1]);
     exit(2);
   }
  fp2=fopen(argv[2],"wb");
  if(fp2==0)
   {
     printf("����:�ļ� \"%s\" �򿪴���!\n",argv[2]);
     fclose(fp1);
     exit(3);
   }
   fseek(fp1,32,1);
   fread(&xsize,4,1,fp1);
   fread(&ysize,4,1,fp1);
   ground=fgetc(fp1);
   fseek(fp1,7,1);
   strcpy(name,"2D��ͼ�༭��");
   fwrite(name,24,1,fp2);
   buf=0x00010000;
   fwrite(&buf,4,1,fp2);
   buf=0;
   fwrite(&buf,4,1,fp2);
   fwrite(&xsize,4,1,fp2);
   fwrite(&ysize,4,1,fp2);
   buf=5;
   fwrite(&buf,4,1,fp2);
   buf=2;
   fwrite(&buf,4,1,fp2);
   strcpy(name,"�ر���");
   fwrite(name,16,1,fp2);
   strcpy(name,"�����");
   fwrite(name,16,1,fp2);
   strcpy(name,"�ϰ���");
   fwrite(name,16,1,fp2);
   strcpy(name,"ͨ���");
   fwrite(name,16,1,fp2);
   strcpy(name,"�����");
   fwrite(name,16,1,fp2);
   for(y=0;y<ysize;y++)
    for(x=0;x<xsize;x++)
    {
      fread(&s1,2,1,fp1);
      s2=0;
      s3=0;
      s4=0;
      if(s1==0)
	s1=919;
      if(s1>=0xf000)
       {
	 s4=s1-0xf000;
	 if(s4==0)
	   s4=1;
	 s1=301;
       }
      if(s1>=0x5000&&s1<0xa000)
       {
	 s3=s1-0x5000+1;
	 s1=306;
       }
      if(s1>=0xa000)
       {
	  s2=1;
	  s1=s1-0xa000;
       }
      fwrite(&ground,2,1,fp2);
      fwrite(&s1,2,1,fp2);
      fwrite(&s2,2,1,fp2);
      fwrite(&s3,2,1,fp2);
      fwrite(&s4,2,1,fp2);
    }
   fclose(fp2);
   fclose(fp1);
}