﻿// Upgrade NOTE: replaced 'mul(UNITY_MATRIX_MVP,*)' with 'UnityObjectToClipPos(*)'

Shader "StarNight"
{
    Properties
    {
        _AntiAnaliseLevel("Anti-Analise Level", Range(0.0, 1.0)) = 0.5
        _ScreenResolution("Screen Resolution",Vector)=(960.0,640.0,0,0)
    }

    CGINCLUDE
    #include "UnityCG.cginc"
    #pragma target 3.0

    // 从顶点着色器输出到片元着色器的数据结构体
    struct v2f 
    {
        float4 pos : SV_POSITION;   // 基于裁剪空间的坐标
        float4 scrPos : TEXCOORD0;  // 基于平面空间的顶点坐标
    };

    v2f vert(appdata_base v)
    {
        v2f o;
        o.pos = UnityObjectToClipPos (v.vertex);
        o.scrPos = ComputeScreenPos(o.pos);
        return o;
    }

    const float HALF_PI = 3.1415 / 2.0;
    float _AntiAnaliseLevel = 1.5;
    float2 _ScreenResolution = float4(960.0,640.0,0.0,0.0);

    // p: 待判断的点
    // a: 线段端点a
    // b: 线段的另一个端点b
    float SegmentSDF(float2 p,float2 a, float2 b)
    {
        float2 v = p - a;
        float2 u = b - a;
        float t = max(min((u.x * v.x + u.y * v.y) / (u.x * u.x + u.y * u.y),1.0),0.0);
        float2 dist = v - u * float2(t,t);
        return sqrt(dist.x*dist.x+dist.y*dist.y);
    }

    // abc是三角形的三个顶点，p是待判定的点，本函数计算连线ab与连线ap的叉积的z分量，
    // 计算连线ab和连线ap的叉积的z分量，如果连线ap和连线ac的z分量同符号的话，
    // 表示连线ap和连线ac在连线ab的同一侧，返回true，否则分居两侧，返回false
    bool IsSameSide(float2 p, float2 a, float2 b, float2 c)
    {
        float2 ab = b - a;
        float2 ac = c - a;
        float2 ap = p - a;
        float f1 = ab.x * ac.y - ab.y * ac.x;
        float f2 = ab.x * ap.y - ab.y * ap.x;
        return f1*f2 >= 0.0;
    }

    // abc是三角形的三个顶点，p是待判定的点，对于任意一个点 ，当它和三角形的任意一个角
    // 顶点的连线向量，它和这任意角的夹角边向量的叉积朝向，和这任意角的两个夹角边向量之
    // 间的叉积的朝向，如果同向的话，就表示该点在三角形内，如果不同向的话就在三角形外。
    bool IsPointInTriangle(float2 p, float2 a, float2 b, float2 c)
    {
        return IsSameSide(p, a, b, c) && IsSameSide(p,b,c,a) && IsSameSide(p,c, a, b);
    }

    // p是待判定的点，center是圆心，radius是圆的半径
    float CircleSDF(float2 p, float2 center, float radius)
    {
        return distance(p, center) - radius;
    }
    
    float TriangleSDF(float2 p, float2 a, float2 b, float2 c)
    {
        float d = min(min(SegmentSDF(p,a,b),SegmentSDF(p,b,c)),SegmentSDF(p,c,a));
        return IsPointInTriangle(p,a,b,c) ? -d : d;
    }

    float RectangleSDF(float2 p, float2 center, float2 halfWH, float theta)
    {
        float cosTheta = cos(theta);
        float sinTheta = sin(theta);
        float dx = abs((p.x - center.x) * cosTheta + (p.y - center.y) * sinTheta) - halfWH.x;
        float dy = abs((p.y - center.y) * cosTheta - (p.x - center.x) * sinTheta) - halfWH.y;
        float2 axy = max(float2(dx,dy), float2(0.0,0.0));
        return min(max(dx, dy), 0.0) + length(axy);
    }
    
    // 几何体SDF的并集
    float UnionSDF(float sdf_a, float sdf_b )
    {
        return sdf_a < sdf_b ? sdf_a : sdf_b;
    }
    
    // 几何体A减去其与几何体B交集部分所剩余的部分
    float SubtractSDF(float sdf_a, float sdf_b)
    {
        float r = sdf_a;
        r = (sdf_a > -sdf_b) ? sdf_a : -sdf_b;
        return r;
    }
    
    // 几何体A与B的交集
    float IntersectSDF(float sdf_a, float sdf_b)
    {
        float r = sdf_a > sdf_b ? sdf_b : sdf_a;
        r = sdf_a > sdf_b ? sdf_a : sdf_b;
        return r;
    }

    // shape是几何体的一个顶点，angle是几何体绕其几何中心点旋转的弧度值
    // 返回旋转后的顶点位置坐标值
    float2 RotateVertex(float2 shape, float angle)
    {
        float cos_angle = 0.0;
        float sin_angle = 0.0;
        sincos(angle,sin_angle,cos_angle);
        float2 rotated_star = float2(0.0,0.0);
        rotated_star.x = dot(shape , float2(cos_angle,-sin_angle));
        rotated_star.y = dot(shape , float2(sin_angle,cos_angle));
        return rotated_star;
    }
    
    // 获取圆环的SDF
    // p 待判断的点的坐标。
    // circle_centers xy分量是第一个圆的圆心坐标，zw分量是第二个圆的圆心坐标
    float GetRingSDF(float2 p,float4 circle_centers,float2 radius)
    {
        float circle_1_sdf = CircleSDF(p,circle_centers.xy,radius.x);
        float circle_2_sdf = CircleSDF(p,circle_centers.zw,radius.y);
        return SubtractSDF(circle_1_sdf,circle_2_sdf);
    }
    
    // TSR的xy分量分别存储了顶点沿着水平垂直方向上的偏移量，z分量是顶点的缩放值
    // w分量是顶点绕几何中心点旋转的角度
    float GetShipSDF(float4 TSR , float2 p)
    {
        /*
             J-----M----I
             |          |
             |          |
             |          |
             G----------H
        E--F-------------C--B
        \  |             |  /
         \ |             | /
          \|             |/
           D-------------A
        */

        float2 A = float2(0.25,0.0);
        float2 B = float2(0.35,0.1);
        float2 C = float2(0.25,0.1);
        
        float2 D = float2(-0.25,0.0);
        float2 E = float2(-0.35,0.1);
        float2 F = float2(-0.25,0.1);

        float2 G = float2(-0.1,0.1);
        float2 H = float2(0.1,0.1);
        float2 I = float2(0.1,0.25);
        float2 J = float2(-0.1,0.25);
        
        float2 M = float2(0.0,0.25);

        float2 scale = float2(TSR.z,TSR.z);
        float2 translation = float2(TSR.x,TSR.y);

        // ABC右船艏三角形
        float2 a = RotateVertex(A*scale, TSR.w) + translation;
        float2 b = RotateVertex(B*scale, TSR.w) + translation;
        float2 c = RotateVertex(C*scale, TSR.w) + translation;
        float2 d = RotateVertex(D*scale, TSR.w) + translation;
        float2 e = RotateVertex(E*scale, TSR.w) + translation;
        float2 f = RotateVertex(F*scale, TSR.w) + translation;
        float2 m = RotateVertex(M*scale, TSR.w) + translation;
        
        float2 g = RotateVertex(G*scale, TSR.w) + translation;
        float2 h = RotateVertex(H*scale, TSR.w) + translation;
        float2 i = RotateVertex(I*scale, TSR.w) + translation;
        float2 j = RotateVertex(J*scale, TSR.w) + translation;

        // DEF左船艏三角形 
        float dist = TriangleSDF(p,e,d,f);
        
        // ACFD船体矩形
        float2 rectHalfWH = float2((a.x - d.x) * 0.5,(f.y - a.y) * 0.5);
        float2 rectCenter = d + rectHalfWH;
        float distOther = RectangleSDF(p,rectCenter,rectHalfWH,0);
        dist = UnionSDF(dist,distOther);
        
        //ABC右船艏三角形
        distOther = TriangleSDF(p,a,b,c);
        dist = UnionSDF(dist,distOther);

        // GHIJ船舱矩形
        rectHalfWH = float2((h.x - g.x) * 0.5,(j.y - g.y) * 0.5);
        rectCenter = g + rectHalfWH;
        distOther = RectangleSDF(p,rectCenter,rectHalfWH,0);
        dist = UnionSDF(dist,distOther);

        // 船舱顶的圆环型
        // circle_centers xy分量是第一个圆的圆心坐标，zw分量是第二个圆的圆心坐标
        // radius.x是第一个圆的半径，radius.y是第二个圆的半径
        float4 circle_centers = float4(m.x,m.y,m.x,m.y);
        float2 radius;
        radius.x = 0.1 * scale;
        radius.y = 0.08 * scale;
        return UnionSDF(dist, GetRingSDF(p,circle_centers,radius));
    }
    
    float GetOceanSDF(float2 p, float2 leftBottom,float2 rightTop)
    {
         // ACFD船体矩形
        float2 rectHalfWH = float2((rightTop.x - leftBottom.x) * 0.5,
                                   (rightTop.y - leftBottom.y) * 0.5);
        float2 rectCenter = leftBottom + rectHalfWH;
        return RectangleSDF(p,rectCenter,rectHalfWH,0);
    }
    
    // TSR的xy分量分别存储了顶点沿着水平垂直方向上的偏移量，z分量是顶点的缩放值
    // w分量是顶点绕几何中心点旋转的角度
    float GetSingleStarSDF(float4 TSR , float2 p)
    {
        float2 scale = float2(TSR.z,TSR.z);
        float2 translation = float2(TSR.x,TSR.y);
        float2 A = float2(0.0,1.0);
        float2 B = float2(-0.95106,0.30902);
        float2 C = float2(-0.58779,-0.80902);
        float2 D = float2(0.58779,-0.80902);
        float2 E = float2(0.95106,0.30902);
        float2 F = float2(0,-0.38197);
        float2 G = float2(0.36328,-0.11804);
        float2 H = float2(0.22452,0.30902);
        float2 I = float2(-0.22452,0.30902);
        float2 J = float2(-0.36328,-0.11804);
        float2 O = float2(0.0,0.0);
        
        // AHO
        float2 a = RotateVertex(A*scale, TSR.w) + translation;
        float2 h = RotateVertex(H*scale, TSR.w) + translation;
        float2 o = RotateVertex(O*scale, TSR.w) + translation;
        float dist = TriangleSDF(p,a,h,o);
       
        // HEO
        float2 e = RotateVertex(E*scale, TSR.w) + translation;
        float distOther = TriangleSDF(p,h,e,o);
        dist = UnionSDF(dist,distOther);

         // EGO
        float2 g = RotateVertex(G*scale, TSR.w) + translation;
        distOther = TriangleSDF(p,e,g,o);
        dist = UnionSDF(dist,distOther);

        // GDO
        float2 d = RotateVertex(D*scale, TSR.w) + translation;
        distOther = TriangleSDF(p,g,d,o);
        dist = UnionSDF(dist,distOther);

        // DFO
        float2 f = RotateVertex(F*scale, TSR.w) + translation;
        distOther = TriangleSDF(p,d,f,o);
        dist = UnionSDF(dist,distOther);

        // FCO
        float2 c = RotateVertex(C*scale, TSR.w) + translation;
        distOther = TriangleSDF(p,f,c,o);
        dist = UnionSDF(dist,distOther);

        // CJO
        float2 j = RotateVertex(J*scale, TSR.w) + translation;
        distOther = TriangleSDF(p,c,j,o);
        dist = UnionSDF(dist,distOther);

        // JBO
        float2 b = RotateVertex(B*scale, TSR.w) + translation;
        distOther = TriangleSDF(p,j,b,o);
        dist = UnionSDF(dist,distOther);

        // BIO
        float2 i = RotateVertex(I*scale, TSR.w) + translation;
        distOther = TriangleSDF(p,b,i,o);
        dist = UnionSDF(dist,distOther);

        // IAO
        distOther = TriangleSDF(p,i,a,o);
        dist = UnionSDF(dist,distOther);

        return dist;
    }
    
    float4 DrawNightSky(float antialias,float2 fragCoord,float2 sr )
    {
        // 第一个五角星
        float4 TSR = float4(sr.x * 5.0/ 6.0, sr.y * 7.5 / 9.0,10.0 ,0.0);
        float star_dist = GetSingleStarSDF( TSR ,  fragCoord);
        // 第二个五角星
        TSR = float4(sr.x * 0.5, sr.y * 3.0/ 4.0 , 18, atan(5.0/4.0));
        float star_dist_other = GetSingleStarSDF( TSR ,  fragCoord);
        star_dist = UnionSDF(star_dist,star_dist_other);

        float transparent = smoothstep(0, antialias, star_dist);
        return float4(1.0,0.0,0.0, 1-transparent);
    }
    
    // 绘制小船
    float4 DrawShip(float antialias,float2 fragCoord,float4 TSR)
    {
        float3 ship_color_rgb = float3(1.0,1.0,1.0);
        float ship_dist = GetShipSDF(TSR , fragCoord);
        float transparent = smoothstep(0, antialias, ship_dist);
        return float4(ship_color_rgb, 1-transparent);
    }
    
    /*
    ocean_height为海平面高度的比例值
    */
    float4 DrawOcean(float antialias,float2 fragCoord,float2 sr,float ocean_height)
    {
        float3 ocean_color = float3(0.35, 0.53, 0.7);
        float ocean_dist = GetOceanSDF(fragCoord, float2(0.0,0.0),float2(sr.x,sr.y * ocean_height));
        float transparent = smoothstep(0, antialias, ocean_dist);
        return float4(ocean_color,1-transparent);
    }

    float4 frag(v2f _iParam) : COLOR0
    {
        float time_sin = sin(_Time.y);
        float2 fragCoord = _iParam.scrPos.xy/_iParam.scrPos.w * _ScreenResolution.xy;
        
        float4 bgLayer = float4(0.0,0.0,0.0,1.0);
        
        float nightSkyAAL = (time_sin + 2.0) * 1.5 * _AntiAnaliseLevel; // 动态地调整星星的反走样
        float4 starLayer = DrawNightSky(nightSkyAAL,fragCoord,_ScreenResolution.xy); // 绘制夜空
        starLayer = lerp(bgLayer, starLayer, starLayer.a);

        float4 shipTrasform = float4((time_sin + 1.0) * 0.5 * _ScreenResolution.x ,
                                     _ScreenResolution.y * 0.29,240,0);
        float4 shipLayer = DrawShip(_AntiAnaliseLevel,fragCoord,shipTrasform);

        shipLayer = lerp(starLayer, shipLayer, shipLayer.a);
        float ocean_height = time_sin * 0.01 + 0.3;// 控制水面的高度在屏幕高度的0.299到0.301之间
        float4 ocean_layer = DrawOcean(_AntiAnaliseLevel,fragCoord,_ScreenResolution.xy,ocean_height);
        return lerp(shipLayer,ocean_layer,ocean_layer.a);
    }

    ENDCG

    SubShader
    {    
        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            ENDCG    
        }    
    }
    
    FallBack Off
}