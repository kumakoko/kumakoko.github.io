﻿/********************************************************************
	created:	2019/09/10
	created:	10:9:2019   20:24
	filename: 	unity3ddemo\2017430F1\TestTimeScale\Assets\TestTimeScale.cs
	file path:	unity3ddemo\2017430F1\TestTimeScale\Assets
	file base:	TestTimeScale
	file ext:	cs
	author:		www.xionggf.com
	
	purpose:	测试使用Time.timeScale属性变量
*********************************************************************/
using UnityEngine;

public class TestTimeScale : MonoBehaviour
{
    public float m_BallMoveSpeed = 1.0f;
    private bool m_CouldMoving = false; // 能移动吗
    private string m_TimeScaleDesc = "1x Time Scale ";
    private float m_LastLogTime = 0.0f; // 上一次debug.log输出的时刻

    void Start()
    {

    }

    void Update()
    {
        if (m_CouldMoving)
        {
            float yOffset = Time.deltaTime * m_BallMoveSpeed;
            transform.Translate(0, yOffset, 0);

        }

        float curTime = Time.realtimeSinceStartup;

        //if (curTime - m_LastLogTime > 1.0f)
        //{
        //    m_LastLogTime = curTime;
        //    Debug.LogFormat("Time.deltaTime = {0:f3} Time.timeScale = {1:f3} realDeltaTime = {2:f3}", Time.deltaTime, Time.timeScale);
        //}

        Debug.LogFormat("Time.deltaTime = {0:f3} Time.timeScale = {1:f3} realDeltaTime = {2:f3}", Time.deltaTime, Time.timeScale, curTime - m_LastLogTime);
        m_LastLogTime = curTime;
    }

    private void OnGUI()
    {
        GUI.Label(new Rect(10, 10, 150, 50), m_TimeScaleDesc);

        if (GUI.Button(new Rect(10, 10 + 50 + 40, 150, 50), "Start moving"))
        {
            m_CouldMoving = true;
        }

        if (GUI.Button(new Rect(10, 10 + 100 + 40, 150, 50), "Reset & Stop moving"))
        {
            m_CouldMoving = false;
            transform.localPosition = new Vector3(0.0f, -20.0f, 0.0f);
        }

        if (GUI.Button(new Rect(10, 10 + 150 + 40, 150, 50), "2x Time Scale"))
        {
            m_TimeScaleDesc = "2x Time Scale";
            Time.timeScale = 2.0f;
        }

        if (GUI.Button(new Rect(10, 10 + 200 + 40, 150, 50), "0.5x Time Scale"))
        {
            m_TimeScaleDesc = "0.5x Time Scale";
            Time.timeScale = 0.5f;
        }

        if (GUI.Button(new Rect(10, 10 + 250 + 40, 150, 50), "1x Time Scale"))
        {
            m_TimeScaleDesc = "1x Time Scale";
            Time.timeScale = 1.0f;
        }
    }
}
